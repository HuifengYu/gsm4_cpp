const net = require('net');
const logger = require("./logger");
const config = require("./config.json");
// const iconv = require('iconv-lite');

const { sleep, ArrToHexString, workObj } = require('./util')
const port = config.listenPort;

const server = net.createServer();
server.on('error', function (err) {
    console.log(`[${port}]error occured`, err.message);
});
server.on('close', function () {
    console.log(`[${port}]server closed`);
});
server.on('connection', function (socket) {
    socket.on('data', async function (data) {
        // logger.info(`[${port}]server收到数据===>${ArrToHexString(data)}`)
        // logger.info(`[${port}]server收到数据===>${data.toString()}`)
        console.log(`[${port}]server收到数据===>${data.toString()}`)

        if (0x7B === data[0]) {
            // {
            //     "command": "ping",
            //     "ip": "52.89.64.10"
            // }
            workObj.ping(socket, data);
        } else {
            socket.write('data error');
        }

    });
    socket.on('close', function () {
        console.log(`[${port}]connection closed`);

    });
    socket.on('error', function () {
        console.log(`[${port}]connection error`);

    });
});
server.listen(port, () => {
    // logger.info(`listen on ${port}`);
    console.log(`listen on ${port}`);
});











