const dgram = require("dgram");
const iconv = require('iconv-lite');

function udpClient(ip, port, data) {
    return new Promise((resolve, reject) => {
        //转为gbk
        // data = iconv.encode(data, 'gbk');

        const client = dgram.createSocket("udp4");
        client.send(data, port, ip, (err, bytes) => {
            err && reject(err);
        });
        client.on("message", (data) => {
            resolve(data);
            console.log(`udp message=>${data}`);
            // client.close();
            // console.log(`关闭udp连接`);
        });
        client.on("close", (err) => {
            reject('udp close');
        });
        client.on("error", (err) => {
            reject('udp error');
        });


        setTimeout(() => {
            resolve(undefined);
            client && client.close();
            console.log(`超时关闭udp连接`);

        }, 5000);

    })
}


module.exports = udpClient;

