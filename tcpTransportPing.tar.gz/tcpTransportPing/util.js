const logger = require("./logger");
const netClient = require('./netClient');
const udpClient = require('./udpClient');
const pingClient = require('./pingClient');
/**
 * sleep
 * @param {*} s 
 * @returns 
 */
function sleep(s = 1) {
    return new Promise((resolve) => {
        setTimeout(resolve, s * 1000);
    })
}

function ArrToHexString(arr) {
    try {
        let strArr = [];
        for (let str of arr) {
            strArr.push(('00' + str.toString(16)).slice(-2).toUpperCase());
        }
        return strArr.join(' ');
    } catch (error) {
        logger.error(`ArrToHexString异常`);

    }

}

let workObj = {
    async udp(port, socket, data, config) {
        try {
            let recvData = await udpClient(config.device[port].ip, config.device[port].port, data);
            // logger.info(`[${port}]serever收到转发数据===>${ArrToHexString(recvData)}`);
            logger.info(`[${port}]serever收到转发数据===>${recvData}`);
            recvData && socket.write(recvData);



        } catch (error) {
            logger.error(`[${port}]server连接出错=>${error}`);

        }

    },
    async tcp(port, socket, data, config) {
        try {
            // let data = await netClient(config.device[port].ip, config.device[port].port, iconv.encode(data, 'gbk'));
            let recvData = await netClient(config.device[port].ip, config.device[port].port, data);
            // logger.info(`[${port}]serever收到转发数据===>${ArrToHexString(recvData)}`);
            logger.info(`[${port}]serever收到转发数据===>${recvData}`);
            recvData && socket.write(recvData);

        } catch (error) {
            logger.error(`[${port}]server连接出错=>${error}`);
        }

    },
    async ping(socket, data) {
        try {
            // console.log(`ping收到的数据=>${data}`);
            let obj = JSON.parse(data);
            if (obj?.command === 'ping' && obj?.ip) {
                let objStr = JSON.stringify(await pingClient(obj.ip));
                socket.write(objStr);
            } else {
                let objStr = JSON.stringify({ alive: false });
                socket.write(objStr);
            }
        } catch (error) {
            console.log(`ping=>异常=>${error}`);
            let objStr = JSON.stringify({ alive: false });
            socket.write(objStr);

        }

    }
}


module.exports = { sleep, ArrToHexString, workObj }