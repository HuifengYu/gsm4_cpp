const ping = require('ping');

async function pingClient(host) {
    try {
        let res = await ping.promise.probe(host, {
            timeout: 1,
            //windows
            // extra: ['-n', 4]

            //linux
            extra: ['-c', 4]
        });
        // console.log(`ping res =>${JSON.stringify(res)}`)
        return { alive: res.alive };

    } catch (error) {
        return { alive: false };
    }

}

module.exports = pingClient;
