const net = require('net');
const logger = require("./logger");

module.exports = function sendToServer(host, port, sendData) {
    return new Promise((resolve, reject) => {
        let netClient = net.createConnection({ host, port });
        netClient.setTimeout(5000);
        netClient.on('connect', () => {
            netClient.write(sendData);
            //logger.info('netClient数据发送成功');
        });
        netClient.on('data', data => {
            //logger.info(`netClient收到数据===>${data.toString()}`);
            resolve(data);
            console.log(`tcp message=>${data}`);
            // let obj = JSON.parse(data);
            // netClient.end();
            // netClient.destroy();
        });
        netClient.on('error', err => {
            //logger.error('netClient客户端异常:', err);
            reject(err);
            // netClient.destroy();
        });
        netClient.on('timeout', err => {
            //logger.error('netClient客户端异常:', err);
            reject(err);
            // netClient.destroy();
        });
        netClient.on('close', err => {
            //logger.info('netClient客户端链接断开!', err);
            reject(err);
            // netClient.destroy();
        });

        setTimeout(() => {
            resolve(undefined);
            netClient && netClient.destroy();;
            console.log(`超时关闭tcp连接`);

        }, 5000);


    });
}