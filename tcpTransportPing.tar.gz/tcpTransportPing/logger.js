const log4js = require("log4js");

log4js.configure({
    appenders: { logger: { type: "console" } },
    categories: { default: { appenders: ["logger"], level: "all" } }
});
const logger = log4js.getLogger("logger");

module.exports = logger;