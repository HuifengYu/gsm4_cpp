const cluster = require('cluster')
const os = require('os')
let cpus = os.cpus().length/2;

if (cluster.isMaster) {
    for (let i = 0; i < cpus; i++) {
        cluster.fork();
    }
    cluster.on('exit', () => {
        setTimeout(() => {
            cluster.fork()
        }, 5000)
    })
} else {
    require('./work');
    process.on('uncaughtException', (err) => {
        console.error(err);
        process.exit(1);
    });
}